package com.calldetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalldetailsMicroApplicationTests {

	@Test
	void contextLoads() {
	}

}
